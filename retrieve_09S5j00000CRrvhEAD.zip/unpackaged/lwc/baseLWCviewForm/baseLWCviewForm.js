import { LightningElement, api } from 'lwc';

export default class BaseLWCviewForm extends LightningElement {
    @api recordId;
}