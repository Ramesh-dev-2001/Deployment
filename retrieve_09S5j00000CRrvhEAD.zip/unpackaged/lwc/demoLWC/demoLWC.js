import { LightningElement } from 'lwc';

export default class DemoLWC extends LightningElement {
    name ='Ramesh';
    company='Salesforce';
    Designation='Manager';
    salary='$100000';
}