import { LightningElement } from 'lwc';

export default class HelloBinding extends LightningElement {
    greetings = "world";
    firstname ='';
    lastname = '';

    handlechange1(event){
        this.greetings = event.target.value;
    }
    handlechange(event){
        const field = event.target.name;
        if(field==='firstname'){
            this.firstname = event.target.value;
        }else if(field==='lastname'){
            this.lastname = event.target.value;
        }
    }
    get UppercasedFullName (){
        return `${this.firstname} ${this.lastname}`.toLowerCase();
    }
}