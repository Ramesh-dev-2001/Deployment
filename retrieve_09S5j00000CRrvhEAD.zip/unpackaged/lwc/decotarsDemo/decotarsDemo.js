import { LightningElement, api, wire } from "lwc";
import { getRecord } from 'lightning/uiRecordApi';

/*const FIELDS = [
  'Contact.Name', 'Contact.Title', 'Contact.Phone', 'Contact.Email'
];*/

export default class Example extends LightningElement {

  @api recordId;
  record;
  error;

  @wire(getRecord, { recordId: '$recordId', fields:['Account.Name']})
  wiredAccount({error,data}){
    if(data){
      this.record=data;
      this.error=undefined;
    }else if(error){
      this.error=error;
      this.record=undefined;
    }
  }
  get name() {
    return this.record.fields.Name.value;
  }
}
  /*get name() {
    return this.Contact.data.fields.Name.value;
  }

  get title() {
    return this.Contact.data.fields.Title.value;
  }

  get phone() {
    return this.Contact.data.fields.Phone.value;
  }

  get email() {
    return this.Contact.data.fields.Email.value;
  }
 }*/