({
	handlerclick : function(component, event, helper) {
		component.set("v.childvar", "update child value");
	}
})