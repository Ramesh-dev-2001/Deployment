({
	handlerclick : function(component, event, helper) {
		component.set("v.parentvar", "update parent value");
	}
})