({
	helperMethod : function(component,event,helper) {
		var val = event.getSource();
        var msg = val.get("v.label");
        if(msg == "First Button"){
            component.set("v.Message1", msg);
        }else{
            component.set("v.Message2", msg);
        }
	}
})